document.addEventListener('DOMContentLoaded', function() {
    document.querySelector('.copy-button').addEventListener('click', copyGenes);
});

function copyGenes() {
    var genes = document.querySelectorAll('#resultsContainer table td:first-child');
    var genesText = Array.from(genes).map(td => td.textContent).join(' ');
    
    var tempInput = document.createElement("textarea");
    tempInput.value = genesText;
    document.body.appendChild(tempInput);
    tempInput.select();
    document.execCommand("copy");
    document.body.removeChild(tempInput);
    alert("Genes copied to clipboard!");
}

